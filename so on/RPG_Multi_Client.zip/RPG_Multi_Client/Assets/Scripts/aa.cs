﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//using System.IO;
//using System.Runtime.Serialization.Formatters.Binary;
//using System.Runtime.InteropServices;
//using System.Net;
//using System.Net.Sockets;

//namespace Client
//{
//    // 구조체 자체를 안전하지 않은 컨텍스트로 활용
//    unsafe struct PacketStruct
//    {
//        public int integer;
//        public float floating;
//        // fixed 구문을 사용하여 고정 크기 할당
//        public fixed char fString[256];

//        public PacketStruct(int integer, float floating, char[] cString)
//        {
//            this.integer = integer;
//            this.floating = floating;
//            // cString의 포인터 주소 고정
//            fixed (char* cStr = cString)
//            {
//                // fString의 포인터 주소 고정
//                fixed (char* fStr = fString)
//                {
//                    // 문자열 길이 반환
//                    int strlen = Client.StrLen(cStr);
//                    // 아스키코드 문자열로 저장
//                    Encoding.ASCII.GetChars((byte*)cStr, 255, fStr, 255);
//                }
//            }
//        }

//        public string FixedString
//        {
//            get
//            {
//                // fString의 포인터 주소 고정
//                fixed (char* str = fString)
//                {
//                    int strlen = Client.StrLen(str);
//                    // 문자열의 길이만큼 아스키코드 스트링으로 인코딩
//                    return Encoding.ASCII.GetString((byte*)str, strlen);
//                }
//            }
//        }
//    }

//    class Client
//    {
//        public unsafe static int StrLen(char* str)
//        {
//            if (str[0] == '\0')
//                return 0;
//            int i = 0;
//            while (str[i++] != '\0') ;
//            return i + 1;
//        }

//        public unsafe static void MemCpy(byte* src, int srcStart, byte* dest, int destStart, int size)
//        {
//            for (int i = 0; i < size; i++)
//            {
//                (dest + destStart)[i] = (src + srcStart)[i];
//            }
//        }

//        static void Main(string[] args)
//        {
//            Console.WriteLine("C# client");

//            Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
//            IPEndPoint iPEndPoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 4567);
//            sock.Connect(iPEndPoint);

//            byte[] recvBytes = new byte[Marshal.SizeOf(typeof(PacketStruct))];
//            sock.Receive(recvBytes);
//            PacketStruct packet = new PacketStruct();
//            unsafe
//            {

//                fixed (byte* fRecvBytes = recvBytes)
//                {
//                    byte* packetBytes = (byte*)&packet;
//                    MemCpy(fRecvBytes, 0, packetBytes, 0, sizeof(PacketStruct));
//                }
//            }
//            Console.WriteLine($"recv integer: {packet.integer}");
//            Console.WriteLine($"recv floating: {packet.floating}");
//            Console.WriteLine($"recv string: {packet.FixedString}");

//            int sendLen = sock.Send(recvBytes);

//            sock.Close();
//        }
//    }
//}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.InteropServices;

namespace Client
{
    [System.Serializable]
    struct Point3
    {
        public int x, y, z;
        public Point3(int x, int y, int z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }
        public static Point3 CreatePoint3()
        {
            Point3 point3 = new Point3();
            Console.Write("x: "); point3.x = int.Parse(Console.ReadLine());
            Console.Write("y: "); point3.y = int.Parse(Console.ReadLine());
            Console.Write("z: "); point3.z = int.Parse(Console.ReadLine());
            return point3;
        }
    }

    static class Serializer
    {
        static byte[] buffer;

        static Serializer()
        {
            buffer = new byte[0];
        }

        static void SetBufferSize(int size)
        {
            if (buffer.Length == size)
                return;
            else buffer = new byte[size];
        }

        public static byte[] Serialize<T>(T _object)
        {
            int size = Marshal.SizeOf(_object.GetType());
            SetBufferSize(size);
            using (MemoryStream ms = new MemoryStream())
            {
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(ms, _object);
                byte[] msBuffer = ms.ToArray();
                Buffer.BlockCopy(msBuffer, msBuffer.Length - size - 1, buffer, 0, size);
            }
            return buffer;
        }

        public static void Deserialize<T>(byte[] bytes, ref T _object)
        {
            int size = Marshal.SizeOf(_object.GetType());
            using (MemoryStream ms = new MemoryStream())
            {
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(ms, _object);
                byte[] msBuffer = ms.ToArray();
                Buffer.BlockCopy(bytes, 0, msBuffer, msBuffer.Length - size - 1, size);

                ms.SetLength(0);
                ms.Write(msBuffer, 0, msBuffer.Length);
                ms.Position = 0;
                _object = (T)bf.Deserialize(ms);
            }
        }
    }


    class Client
    {
        const int PORT = 4657;

        static void Main(string[] args)
        {
            Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            var ep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 4000);
            sock.Connect(ep);

            Point3 recvPoint3 = new Point3();
            byte[] recvBuf = new byte[Marshal.SizeOf(recvPoint3)];
            int recvLen = sock.Receive(recvBuf);
            Serializer.Deserialize<Point3>(recvBuf, ref recvPoint3);
            Console.WriteLine("(recv) x: {0}, y: {1}, z: {2}", recvPoint3.x, recvPoint3.y, recvPoint3.z);



            Point3 sendPoint3 = new Point3();
            Console.WriteLine("x : ");
            string x = Console.ReadLine();
            sendPoint3.x = Convert.ToInt32(x);

            Console.WriteLine("y : ");
            string y = Console.ReadLine();
            sendPoint3.y = Convert.ToInt32(y);

            Console.WriteLine("z : ");
            string z = Console.ReadLine();
            sendPoint3.z = Convert.ToInt32(z);

            byte[] sendBuf = Serializer.Serialize<Point3>(sendPoint3);


            Serializer.Deserialize<Point3>(sendBuf, ref sendPoint3);
            int sendLen = sock.Send(sendBuf);
            //Console.WriteLine("(send) x: {0}, y: {1}, z: {2}", sendPoint3.x, sendPoint3.y, sendPoint3.z);


            sock.Close();
        }
    }
}